from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField
from wtforms.validators import Length, EqualTo, Email, DataRequired, ValidationError
from app.models import User


class RegisterForm(FlaskForm):
    def validate_username(self, username_to_check):
        user = User.query.filter_by(username=username_to_check.data).first()
        if user:
            raise ValidationError('Username already exists! Please try a different username')

    def validate_tpin(self, tpin_to_check):
        user = User.query.filter_by(tpin=tpin_to_check.data).first()
        if user:
            raise ValidationError('TPIN already exists! Please try a different TPIN')

    def validate_email_address(self, email_address_to_check):
        email_address = User.query.filter_by(email_address=email_address_to_check.data).first()
        if email_address:
            raise ValidationError('Email Address already exists! Please try a different email address')

    username = StringField(label='Customer NRC as Username:', validators=[Length(min=2, max=30), DataRequired()])
    name = StringField(label='Client Name:', validators=[Length(min=1, max=60), DataRequired()])
    tpin = StringField(label='Taxpayer Identification Number:', validators=[Length(min=1, max=60), DataRequired()])
    phone = StringField(label='Phone:', validators=[Length(min=1, max=60), DataRequired()])
    address = StringField(label='Physical/Business Address:', validators=[Length(min=1, max=60), DataRequired()])
    email_address = StringField(label='Email Address:', validators=[Email(), DataRequired()])
    password1 = PasswordField(label='Password:', validators=[Length(min=6), DataRequired()])
    password2 = PasswordField(label='Confirm Password:', validators=[EqualTo('password1'), DataRequired()])

    submit = SubmitField(label='Create Account')


class ApplyForm(FlaskForm):
    plotNo = StringField(label='Plot Number:', validators=[Length(min=2, max=30), DataRequired()])
    street = StringField(label='Street:', validators=[Length(min=1, max=60), DataRequired()])
    township = StringField(label='Township:', validators=[Length(min=1, max=60), DataRequired()])
    town = StringField(label='Phone:', validators=[Length(min=1, max=60), DataRequired()])
    description = StringField(label='Description of Premises:', validators=[Length(min=1, max=60), DataRequired()])
    submit = SubmitField(label='Submit Application')


class LoginForm(FlaskForm):
    username = StringField(label='User Name (NRC):', validators=[DataRequired()])
    password = PasswordField(label='Password:', validators=[DataRequired()])
    submit = SubmitField(label='Sign in')
