import requests

from app import app
from flask import render_template, redirect, url_for, flash, session
from app.models import Application, User
from app.forms import RegisterForm, LoginForm, ApplyForm
from app import db
from flask_login import login_user, logout_user, login_required


@app.route('/')
@app.route('/home')
@app.route('/Home')
def Index():
    return render_template("index.html")


@app.route('/applications')
@login_required
def application_page():
    applications = Application.query.filter_by(owner=session['username'])
    #applications = Application. .query.all(owner=session['username'])
    #attempted_user = Application.query.filter_by(username=form.username.data).first()

    return render_template('applications.html', application=applications)


@app.route('/register', methods=['GET', 'POST'])
def register_page():
    form = RegisterForm()

    if form.validate_on_submit():
        BASE = "http://127.0.0.1:5001/"
        text_id = form.username.data
        response = requests.get(BASE + "getTPIN/" + text_id)
        try:
            text = response.json()
        except:
            flash(f"You are not a registered Taxpayer", category='error')
            return render_template('register.html', form=form)
        if text is not None:
            zra_tpin = text["tpin"]
            if zra_tpin != form.tpin.data:
                flash(f"You have not provided a Valid Taxpayer Identification", category='error')
            else:
                user_to_create = User(username=form.username.data,
                                      name=form.name.data,
                                      tpin=form.tpin.data,
                                      phone=form.phone.data,
                                      address=form.address.data,
                                      email_address=form.email_address.data,
                                      password=form.password1.data)
                db.session.add(user_to_create)
                db.session.commit()
                login_user(user_to_create)
                flash(f"Account created successfully! You are now logged in as {user_to_create.username}",
                      category='success')
                session['username']=user_to_create.username
                return redirect(url_for('application_page'))
        else:
            flash(
                f"You are not a registered Taxpayer. You are required to register with the Zambia Revenue Authority to Access these Services",
                category='error')
        if form.errors != {}:  # If there are no errors from the validations
            for err_msg in form.errors.values():
                flash(f'There was an error with creating a user: {err_msg}', category='danger')
    return render_template('register.html', form=form)


@app.route('/login', methods=['GET', 'POST'])
def login_page():
    form = LoginForm()
    if form.validate_on_submit():
        attempted_user = User.query.filter_by(username=form.username.data).first()
        if attempted_user and attempted_user.check_password_correction(
                attempted_password=form.password.data
        ):
            login_user(attempted_user)
            flash(f'Success! You are logged in as: {attempted_user.username}', category='success')
            session['username'] = form.username.data
            return redirect(url_for('application_page'))
        else:
            flash('Username and password are not match! Please try again', category='danger')

    return render_template('login.html', form=form)


@app.route('/apply', methods=['GET', 'POST'])
def apply_page():
    form = ApplyForm()
    if form.validate_on_submit():
        application_to_create = Application(plotNo=form.plotNo.data,
                                            street=form.street.data,
                                            township=form.township.data,
                                            town=form.town.data,
                                            description=form.description.data,
                                            owner=session['username'])
        db.session.add(application_to_create)
        db.session.commit()
        flash(f"Application created successfully!",
              category='success')
        return redirect(url_for('application_page'))

    return render_template('apply.html', form=form)


@app.route('/logout')
def logout_page():
    logout_user()
    flash("You have been logged out!", category='info')
    return redirect(url_for("Index"))
