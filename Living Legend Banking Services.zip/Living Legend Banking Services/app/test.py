import requests

BASE = "http://127.0.0.1:5000/"

response = requests.get(BASE + "getTPIN/769170111")
print(response.json())
