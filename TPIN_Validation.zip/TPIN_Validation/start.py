# ---------------------------- TPIN Verification Service
# ---------------------------- Created By Christopher Kabamba
# ---------------------------- June 2022

# -- Import Libraries
from flask import Flask
from flask_restful import Api, Resource
from flask_sqlalchemy import SQLAlchemy

# -- Connect to Database
app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///zra.db'
db = SQLAlchemy(app)
api = Api(app)
# -- Define Class to represent database Table
class Taxpayer(db.Model):
    tpin = db.Column(db.String(length=10), primary_key=True)
    nrc = db.Column(db.String(length=60), nullable=False)
    taxpayer_name = db.Column(db.String(length=60), nullable=False)

    def __repr__(self):
        return f'Taxpayer {self.name}'
# -- Retrieve Data from Database
class getTPIN(Resource):
    def get(self, name):
        exists = db.session.query(db.exists().where(Taxpayer.nrc == name)).scalar()
        if exists:
            for taxpayer in Taxpayer.query.filter_by(nrc=name):
                names = {taxpayer.nrc: {"tpin": taxpayer.tpin, "taxpayer_name": taxpayer.taxpayer_name}}
            return names[name]
api.add_resource(getTPIN, "/getTPIN/<string:name>")
if __name__ == "__main__":
    app.run(host='127.0.0.1', port=5001, debug=True)
